var searchData=
[
  ['description_556',['Description',['../class_net_market_1_1_models_1_1_product.html#a473acf723d26968db7c5aa633e37671c',1,'NetMarket.Models.Product.Description()'],['../class_net_market_1_1_view_models_1_1_new_product_view_model.html#af498e86d70af3e99b11e3eb5bff4c4ee',1,'NetMarket.ViewModels.NewProductViewModel.Description()'],['../class_net_market_1_1_view_models_1_1_product_view_model.html#a9f1926f5b2bfd9fb9d735d1e49a75a0a',1,'NetMarket.ViewModels.ProductViewModel.Description()']]]
];
