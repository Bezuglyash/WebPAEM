var searchData=
[
  ['aspnetcore_351',['AspNetCore',['../namespace_asp_net_core.html',1,'']]]
];
