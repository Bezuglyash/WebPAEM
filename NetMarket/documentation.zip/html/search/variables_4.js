var searchData=
[
  ['http_532',['http',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a6d3eab50ac31e5cfcbf63fa745e12872',1,'http():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a6d3eab50ac31e5cfcbf63fa745e12872',1,'http():&#160;LICENSE.txt']]],
  ['https_533',['https',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a9e1a04b58cc473796394d8f562288114',1,'https():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a9e1a04b58cc473796394d8f562288114',1,'https():&#160;LICENSE.txt']]]
];
