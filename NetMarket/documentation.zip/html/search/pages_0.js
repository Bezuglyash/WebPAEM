var searchData=
[
  ['the_20mit_20license_20_28mit_29_603',['The MIT License (MIT)',['../md__d___repozitories__web_p_a_e_m__net_market_obj__release_netcoreapp3_81__pub_tmp__out_wwwroot_df9397ce99e69b2df7548e7d23773c13.html',1,'']]],
  ['the_20mit_20license_20_28mit_29_604',['The MIT License (MIT)',['../md__d___repozitories__web_p_a_e_m__net_market_wwwroot_lib_jquery-validation__l_i_c_e_n_s_e.html',1,'']]]
];
