var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw",
  1: "aeilmnoprsuv",
  2: "an",
  3: "_aceilmnoprsuw",
  4: "abcdefgilmnoprsuvw",
  5: "bcdfhiklmoprstu",
  6: "acdehijlmnoprsuw",
  7: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные",
  6: "Свойства",
  7: "Страницы"
};

