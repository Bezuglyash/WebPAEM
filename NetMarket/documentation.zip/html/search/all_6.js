var searchData=
[
  ['files_65',['files',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a35cf543899fd710ec05aaa62e2804ed9',1,'files(the &quot;Software&quot;):&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a35cf543899fd710ec05aaa62e2804ed9',1,'files(the &quot;Software&quot;):&#160;LICENSE.txt']]],
  ['from_66',['FROM',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#ad20dada78dc01ff9f6a9eba39b737a79',1,'FROM():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#ad20dada78dc01ff9f6a9eba39b737a79',1,'FROM():&#160;LICENSE.txt']]]
];
