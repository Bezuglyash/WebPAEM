var searchData=
[
  ['marketcontroller_2ecs_384',['MarketController.cs',['../_market_controller_8cs.html',1,'']]],
  ['myorders_2ecshtml_2eg_2ecs_385',['MyOrders.cshtml.g.cs',['../_my_orders_8cshtml_8g_8cs.html',1,'']]]
];
