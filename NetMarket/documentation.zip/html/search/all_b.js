var searchData=
[
  ['kind_105',['KIND',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#ab32eaa76edf5a371670da2291d1bc1ef',1,'KIND():&#160;LICENSE.txt'],['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#ae682d8dbab53b032858b0f40d1a05c4d',1,'KIND():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#ab32eaa76edf5a371670da2291d1bc1ef',1,'KIND():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#ae682d8dbab53b032858b0f40d1a05c4d',1,'KIND():&#160;LICENSE.txt']]]
];
