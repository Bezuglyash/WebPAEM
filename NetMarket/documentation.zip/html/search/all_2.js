var searchData=
[
  ['basis_16',['BASIS',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a7481bdf69521f23e12265ac712583b87',1,'BASIS():&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a7481bdf69521f23e12265ac712583b87',1,'BASIS():&#160;LICENSE.txt']]],
  ['buildwebhost_17',['BuildWebHost',['../class_program.html#a2ca63344f642852328702dd0be847af2',1,'Program']]]
];
