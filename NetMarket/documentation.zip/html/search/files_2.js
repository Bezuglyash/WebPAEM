var searchData=
[
  ['cart_2ecshtml_2eg_2ecs_371',['Cart.cshtml.g.cs',['../_debug_2netcoreapp3_81_2_razor_2_views_2_market_2_cart_8cshtml_8g_8cs.html',1,'(Глобальное пространство имён)'],['../_release_2netcoreapp3_81_2_razor_2_views_2_home_2_cart_8cshtml_8g_8cs.html',1,'(Глобальное пространство имён)']]]
];
