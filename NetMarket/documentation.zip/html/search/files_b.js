var searchData=
[
  ['searchbyname_2ecs_422',['SearchByName.cs',['../_search_by_name_8cs.html',1,'']]],
  ['searchbyordernumber_2ecs_423',['SearchByOrderNumber.cs',['../_search_by_order_number_8cs.html',1,'']]],
  ['settings_2ecshtml_2eg_2ecs_424',['Settings.cshtml.g.cs',['../_settings_8cshtml_8g_8cs.html',1,'']]],
  ['staffcontroller_2ecs_425',['StaffController.cs',['../_staff_controller_8cs.html',1,'']]],
  ['startup_2ecs_426',['Startup.cs',['../_startup_8cs.html',1,'']]]
];
