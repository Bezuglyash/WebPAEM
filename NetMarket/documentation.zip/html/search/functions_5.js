var searchData=
[
  ['files_459',['files',['../obj_2_release_2netcoreapp3_81_2_pub_tmp_2_out_2wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a35cf543899fd710ec05aaa62e2804ed9',1,'files(the &quot;Software&quot;):&#160;LICENSE.txt'],['../wwwroot_2lib_2jquery_2_l_i_c_e_n_s_e_8txt.html#a35cf543899fd710ec05aaa62e2804ed9',1,'files(the &quot;Software&quot;):&#160;LICENSE.txt']]]
];
