var searchData=
[
  ['warehouse_522',['Warehouse',['../class_net_market_1_1_controllers_1_1_staff_controller.html#a2f898f73d5a0a7e228eee5f944bc5a4c',1,'NetMarket.Controllers.StaffController.Warehouse()'],['../class_net_market_1_1_controllers_1_1_staff_controller.html#ab8b53f96358969bb97bc297f3abcaf54',1,'NetMarket.Controllers.StaffController.Warehouse(string? textSearch, int? idWhichProductMustDelete)']]]
];
