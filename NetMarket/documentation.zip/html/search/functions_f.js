var searchData=
[
  ['updateasync_518',['UpdateAsync',['../class_net_market_1_1_repository_1_1_people_repository.html#a3f16027187dfaca6a00294dc58f9bb5e',1,'NetMarket.Repository.PeopleRepository.UpdateAsync()'],['../class_net_market_1_1_repository_1_1_product_repository.html#aefff88930168216564c7530bae546d15',1,'NetMarket.Repository.ProductRepository.UpdateAsync()']]],
  ['updaterole_519',['UpdateRole',['../class_net_market_1_1_controllers_1_1_staff_controller.html#a9b3eb60df4546a88ae7e75faed2aba0e',1,'NetMarket::Controllers::StaffController']]],
  ['updatestatus_520',['UpdateStatus',['../class_net_market_1_1_controllers_1_1_staff_controller.html#aa976b1e53ab5d16ce94005eb212e45b7',1,'NetMarket::Controllers::StaffController']]]
];
